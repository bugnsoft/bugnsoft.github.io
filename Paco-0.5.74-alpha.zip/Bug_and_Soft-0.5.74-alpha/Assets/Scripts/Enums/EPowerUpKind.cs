using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum EPowerUpKind
{
    NONE,
    TELEPORT,
    SHIELD,
    GODLIKE
}
