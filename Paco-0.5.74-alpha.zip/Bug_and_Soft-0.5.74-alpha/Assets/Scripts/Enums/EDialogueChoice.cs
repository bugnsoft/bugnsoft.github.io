﻿public enum EDialogueChoice
{
    NONE,
    OPEN_SHOP,
    ACCEPT_COMPANION
}