﻿namespace Enums
{
    public enum EButtonFunction
    {
        NONE,
        QUIT,
        SETTINGS,
        MAINMENU,
        RETRY,
        RESUME,
        SAVE,
        LOAD,
        SAVENOW,
        LOADNOW
    }
}