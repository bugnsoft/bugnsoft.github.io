namespace Controllers
{
    public enum ECharacterKind
    {
        Dummy = 1,
        Njord,
        Froggy,
        OLC,
        Mortadelo,
        Zanopiano,
        Pitonesi,
        Pepe,
        VERGEN
    }
}