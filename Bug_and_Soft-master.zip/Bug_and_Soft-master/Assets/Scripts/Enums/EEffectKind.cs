﻿namespace Enums
{
    public enum EEffectKind
    {
        POISON,
        STUN,
        SLOWDOWN,
        FIRE
    }
}