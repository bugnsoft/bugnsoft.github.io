using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Controllers
{
    public enum EControllerKind
    {
        NPC = 1,
        Enemy,
        Neutral,
        Boss
    }
}