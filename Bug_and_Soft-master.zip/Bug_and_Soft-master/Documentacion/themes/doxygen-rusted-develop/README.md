# doxygen-rusted

This repository holds a custom [Doxygen][] theme.

**NOTE:** The project is not under active development.

## Example Screenshots

![](https://user-images.githubusercontent.com/78555315/107052893-7f347400-67ce-11eb-821f-2dd7e270603f.png)

---

![](https://user-images.githubusercontent.com/78555315/107052895-7fcd0a80-67ce-11eb-9a37-0a820a59a0d4.png)

---

![](https://user-images.githubusercontent.com/78555315/107052896-8065a100-67ce-11eb-809d-4f8ff6debd22.png)

---

![](https://user-images.githubusercontent.com/78555315/107052899-8065a100-67ce-11eb-86aa-12e51ce9918a.png)

---

![](https://user-images.githubusercontent.com/78555315/107052900-80fe3780-67ce-11eb-9aa5-8bc7d6713207.png)

## License

The project is licensed under the MIT license. See [LICENSE](LICENSE) for more
information.

[Doxygen]: http://www.stack.nl/~dimitri/doxygen/index.html
