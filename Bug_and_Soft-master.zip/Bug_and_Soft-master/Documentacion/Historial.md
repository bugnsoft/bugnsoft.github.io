# Bug&Soft Documentation : Historial de Clases

## 0.3.12
![](https://github.com/DrAsin/Bug_and_Soft/blob/master/Documentacion/0.3.12/UML.png)

## 0.1.9
![](https://github.com/DrAsin/Bug_and_Soft/blob/master/Documentacion/0.1.9/UML.png)

## 0.0.8
![](https://github.com/DrAsin/Bug_and_Soft/blob/master/Documentacion/0.0.8/UML.png)