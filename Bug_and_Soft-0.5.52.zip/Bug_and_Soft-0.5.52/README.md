# Bug&Soft

### Codigo fuente del proyecto final para 3BD videojuegos

PAGINA OFFICIAL [Click aca](https://bugnsoft.github.io/)

UNITY VERSION : 2020.3.15f1

#### Integrantes:
- Bruno Baz
- Kevin Rodriguez
- Juan Garcia
- Nicolas Cabrera
