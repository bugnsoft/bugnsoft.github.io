﻿namespace Interactions.Enums
{
    public enum EInteractionKind
    {
        Dialogue = 0,
        Shop,
        QuickChat,
        GainAbility,
        Dojo
    }
}