﻿namespace Enums
{
    public enum EButtonFunction
    {
        QUIT,
        SETTINGS,
        MAINMENU,
        RETRY,
        RESUME
    }
}