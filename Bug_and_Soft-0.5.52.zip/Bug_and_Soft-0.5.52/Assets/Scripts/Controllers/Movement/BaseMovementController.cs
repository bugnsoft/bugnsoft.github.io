using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Controllers.Movement
{
    public class BaseMovementController : 
    /// @cond SKIP_THIS
        MonoBehaviour
    /// @endcond
    {
        // Start is called before the first frame update
        void Start()
        {

        }

        // Update is called once per frame
        void Update()
        {

        }
    }
}