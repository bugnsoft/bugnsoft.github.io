namespace Controllers
{
    public enum ECharacterKind
    {
        Dummy = 1,
        Njord,
        Froggy,
        OLC
    }
}