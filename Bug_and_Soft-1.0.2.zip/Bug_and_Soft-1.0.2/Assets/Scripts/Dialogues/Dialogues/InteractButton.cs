﻿using UnityEngine.Events;

namespace Dialogues.Dialogues
{
    public struct InteractButton
    {
        public UnityAction Callback;
        public string Text;
    }
}