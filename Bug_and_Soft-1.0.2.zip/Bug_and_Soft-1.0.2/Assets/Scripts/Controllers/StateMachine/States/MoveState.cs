﻿namespace Controllers.StateMachine.States
{
    public class MoveState
    {
        
    }
}