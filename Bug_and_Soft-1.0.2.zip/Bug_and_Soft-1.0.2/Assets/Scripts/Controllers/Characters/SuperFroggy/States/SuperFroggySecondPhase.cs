﻿using System.Collections;
using UnityEngine;

namespace Assets.Scripts.Controllers.Characters.SuperFroggy.States
{
    public class SuperFroggySecondPhase : MonoBehaviour
    {

        // Use this for initialization
        void Start()
        {

        }

        // Update is called once per frame
        void Update()
        {

        }
    }
}