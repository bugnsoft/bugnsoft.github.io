﻿public enum EItemKind
{
    HEALTH_POTION,
    KRONES
}