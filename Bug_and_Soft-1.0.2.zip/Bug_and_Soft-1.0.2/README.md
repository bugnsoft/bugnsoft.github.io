# Bug&Soft

### Codigo fuente del proyecto final para 3BD videojuegos

<img src="https://github.com/nclettiere/Bug_and_Soft/blob/master/.github/CXrmKEbWEAAXYYO.png?raw=true" />

PAGINA OFFICIAL [Click aca](https://bugnsoft.github.io/)

UNITY VERSION : 2020.3.12f1

#### Integrantes:
- Bruno Baz
- Kevin Rodriguez
- Juan Garcia
- Nicolas Cabrera
